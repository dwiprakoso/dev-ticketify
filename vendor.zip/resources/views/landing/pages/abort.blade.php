@extends('landing.layouts.app')

{{-- abort.blade.php --}}
@section('content')
    <!-- card -->
    <div class="container mx-auto p-4 mb-5">
        <h5 class="text-2xl font-bold tracking-tight text-black mb-4">404</h5>
            <h1 class="text-xl font-semibold text-center mt-[200px] mb-[200px]">Oops, 404 Not Found.</h1>

    </div>
    <!-- end card -->
@endsection
