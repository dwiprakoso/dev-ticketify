<?php $__env->startSection('content'); ?>
    <!-- card -->
    <div class="container mx-auto p-4 mb-5">
        <h5 class="text-2xl font-bold tracking-tight text-black mb-4">404</h5>
            <h1 class="text-xl font-semibold text-center mt-[200px] mb-[200px]">Oops, 404 Not Found.</h1>

    </div>
    <!-- end card -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Coding\api_ticketing_midtrans\resources\views/landing/pages/abort.blade.php ENDPATH**/ ?>