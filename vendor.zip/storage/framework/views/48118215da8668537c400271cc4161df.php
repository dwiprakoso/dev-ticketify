<?php $__env->startSection('title', 'Detail Pembeli'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto mt-24">
    <form method="GET" action="<?php echo e(route('admin.buyerDetail', ['event_id' => request('event_id')])); ?>" class="mb-4">
        <div class="flex items-center space-x-4">
            
            <div class="relative">
                <label for="keyword" class="block text-sm font-medium text-gray-700 dark:text-gray-400">Cari No Transaksi, Nama, atau Email</label>
                <input type="text" id="keyword" name="keyword" class="form-input mt-1 block w-full" value="<?php echo e(request('keyword')); ?>" placeholder="Masukkan kata kunci">
            </div>
            <div class="relative">
                <button type="submit" class="mt-6 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Filter
                </button>
            </div>
        </div>
    </form>
    
    <?php if($orders->isEmpty()): ?>
        <h1 class="text-center text-xl mt-8">Oops, tidak ada data pembeli untuk acara ini.</h1>
    <?php else: ?>
    <div class="mt-4 mb-8">
        <a href="<?php echo e(route('admin.export')); ?>" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">Export to Excel</a>
        <h2 class="text-black font-bold pt-4 rounded">Total Pendapatan : Rp&nbsp;<?php echo e(number_format($totalRevenue, 0, ',', '.')); ?></h2>
    </div>
        <div class="relative overflow-x-auto shadow-md sm:rounded-lg border border-black">
            <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400 table-border">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">NO</th>
                        <th scope="col" class="px-6 py-3">Status Pembayaran</th>
                        <th scope="col" class="px-6 py-3">Ticket Type</th>
                        <th scope="col" class="px-6 py-3">Tiket acara yang Dibeli</th>
                        <th scope="col" class="px-6 py-3">Pemesanan pada</th>
                        <th scope="col" class="px-6 py-3">No Transaksi</th>
                        <th scope="col" class="px-6 py-3">Nama Orang Tua</th>
                        <th scope="col" class="px-6 py-3">Nama Anak</th>
                        <th scope="col" class="px-6 py-3">Usia Anak</th>
                        <th scope="col" class="px-6 py-3">Email Pembeli</th>
                        <th scope="col" class="px-6 py-3">Gender</th>
                        <th scope="col" class="px-6 py-3">No HP</th>
                        <th scope="col" class="px-6 py-3">Tanggal Lahir</th>
                        <th scope="col" class="px-6 py-3">Jumlah Pembelian</th>
                        <th scope="col" class="px-6 py-3">Harga</th>
                        <th scope="col" class="px-6 py-3">Total Harga</th>
                        <?php if($orders->first()->event->event_type == 'health'): ?>
                            <th scope="col" class="px-6 py-3">NIK</th>
                            <th scope="col" class="px-6 py-3">BIB</th>
                            <th scope="col" class="px-6 py-3">Golongan Darah</th>
                            <th scope="col" class="px-6 py-3">Komunitas</th>
                            <th scope="col" class="px-6 py-3">Kontak Darurat</th>
                            <th scope="col" class="px-6 py-3">Ukuran Baju</th>
                            <th scope="col" class="px-6 py-3">Nama Acara</th>
                            <th scope="col" class="px-6 py-3">Nomor Kontak Darurat</th>
                            <th scope="col" class="px-6 py-3">Hubungan Kontak Darurat</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700">
                            <td class="px-6 py-4"><?php echo e($index + 1); ?></td>
                            <td class="px-6 py-4 font-extrabold"><?php echo e($order->status); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->ticket_type); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($order->event->event_name); ?></td>
                            <td class="px-6 py-4"><?php echo e(\Carbon\Carbon::parse($order->created_at)->translatedFormat('l, d F Y')); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->no_transaction); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->name_buyer); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->first_name); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->last_name); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->email_buyer); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->gender); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->phone_number); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->birth_date); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->qty); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->price); ?></td>
                            <td class="px-6 py-4"><?php echo e($order->total_amount); ?></td>
                            <?php if($order->event->event_type == 'health'): ?>
                                <td class="px-6 py-4"><?php echo e($order->nik); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->bib); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->blood_type); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->community); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->urgent_contact); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->size_shirt); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->event_name); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->number_urgen_contact); ?></td>
                                <td class="px-6 py-4"><?php echo e($order->relation_urgen_contact); ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Coding\api_ticketing_midtrans\resources\views/admin/page/buyerDetail.blade.php ENDPATH**/ ?>