<!-- resources/views/admin/index.blade.php -->


<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
    <div class="bg-orange-500 text-white p-4 rounded-lg">
      <div class="text-2xl font-bold"><?php echo e($totalTickets); ?></div>
      <div class="text-lg">Ticket Anda</div>
    </div>
    <div class="bg-green-500 text-white p-4 rounded-lg">
      <div class="text-2xl font-bold"><?php echo e($totalEventsa); ?></div>
      <div class="text-lg">Event Anda</div>
    </div>
    <div class="bg-blue-500 text-white p-4 rounded-lg">
      <div class="text-2xl font-bold"><?php echo e($totalOrders); ?></div>
      <div class="text-lg">Pembeli Anda</div>
    </div>
    <div class="bg-purple-500 text-white p-4 rounded-lg">
      <div class="text-2xl font-bold"><?php echo e($totalTalents); ?></div>
      <div class="text-lg">Talent Anda</div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Coding\api_ticketing_midtrans\resources\views/admin/index.blade.php ENDPATH**/ ?>