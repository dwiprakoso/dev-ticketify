<?php $__env->startSection('title', 'Pembeli'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $bgColors = ['bg-green-500', 'bg-blue-500', 'bg-yellow-500', 'bg-red-500', 'bg-purple-500'];
            $randomColor = $bgColors[array_rand($bgColors)];
        ?>
        <a href="<?php echo e(route('admin.buyerDetail', ['event_id' => $event->event_id])); ?>" class="<?php echo e($randomColor); ?> text-white p-4 rounded-lg">
            <div class="text-xl font-bold">Nama Event:</div>
            <div class="text-2xl font-bold"><?php echo e($event->event_name); ?></div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Coding\api_ticketing_midtrans\resources\views/admin/page/buyer.blade.php ENDPATH**/ ?>