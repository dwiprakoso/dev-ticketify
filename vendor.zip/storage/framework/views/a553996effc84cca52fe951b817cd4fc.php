<?php $__env->startSection('content'); ?>
    <!-- hero -->
    <div class="container mx-auto px-4 py-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="flex justify-center pt-3">
                <img src="<?php echo e(asset('storage/' . $event->event_picture)); ?>"
                    class="w-[800px] h-[400px] object-cover" alt="Event Image" />
            </div>
            <div class="bg-white p-6 rounded-lg border-2 border-black">
                <h2 class="text-2xl font-bold mb-4"><?php echo e($event->event_name); ?></h2>
                <h2 class="text-2xl font-bold mb-4"><?php echo e($event->event_status); ?></h2>
                <div class="text-gray-700 mb-4">
                    <p><?php echo e(\Carbon\Carbon::parse($event->event_start)->translatedFormat('j F Y')); ?>-<?php echo e(\Carbon\Carbon::parse($event->event_ended)->translatedFormat('j F Y')); ?></p>
                    <p><?php echo e($event->event_location); ?></p>
                </div>
                <h3 class="text-xl font-semibold mt-8 mb-2">Ticket Categories</h3>
                <div class="space-y-2">
                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center p-2 border border-gray-300 rounded">
                            <div class="flex-1 truncate pr-4"><?php echo e($ticket->ticket_type); ?></div>
                            <div class="w-32 text-right">Rp <?php echo e(number_format($ticket->price, 0, ',', '.')); ?></div>
                            <button onclick="window.location.href='<?php echo e(route('order', ['event_id' => $event->event_id, 'ticket_id' => $ticket->ticket_id])); ?>'"
                                class="ml-4 bg-[#454545] text-white px-4 py-2 rounded">Pesan</button>                            
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
    <!-- end hero -->

    <!-- description -->
    <section class="container md:px-32 md:py-10 py-7 px-4">
        <div class="flex flex-col text-wrap md:ml-16">
            <h1 class="text-4xl font-bold mb-4">Deskripsi Event</h1>
            <p class="text-xl">
                <?php echo e($event->event_description); ?>

            </p>
        </div>
    </section>
    <!-- end description -->

    <!-- lineup -->
    <div class="bg-amber-200 py-8">
        <div class="container mx-auto px-4 text-center">
            <button class="bg-black text-white px-4 py-2 rounded-lg mb-4">Line up</button>
            <?php if($talents->isEmpty()): ?>
                <p class="text-gray-700">Coming Soon</p>
            <?php else: ?>
                <div class="grid grid-cols-2 md:grid-cols-6 gap-4">
                    <?php $__currentLoopData = $talents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $talent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button class="bg-white py-2 rounded-lg"><?php echo e($talent->name); ?></button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- end lineup -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('landing.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Coding\api_ticketing_midtrans\resources\views/landing/pages/event/page/details.blade.php ENDPATH**/ ?>